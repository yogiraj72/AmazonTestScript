import logging


class LogGen:

    @staticmethod
    def loggen():
        logger = logging.getLogger(__name__)
        filehandler = logging.FileHandler('.\\logs\\logging.log')

        formatter = logging.Formatter("%(asctime)s: %(levelname)s: %(name)s: %(message)s")

        filehandler.setFormatter(formatter)

        logger.addHandler(filehandler)

        logger.setLevel(logging.INFO)



       # logging.basicConfig(filename="automation.log",
        #                    format='%(asctime)s: %(levelname)s: %(message)s',
       #                     datefmt='%m/%d/%Y %I:%M:%S %p')
       # logger = logging.getLogger()
       # logger.setLevel(logging.INFO)
        return logger
