import time

import pytest
from selenium import webdriver
from pageObjects.searchProduct import SearchProduct
from utilities.readConfig import ReadConfig
from utilities.customLogger import LogGen


class TestCaseSearch:
    baseURL = ReadConfig.getappurl()
    searchWord = ReadConfig.searchword()
    minValue = ReadConfig.minvalue()
    maxValue = ReadConfig.maxvalue()

    logger = LogGen.loggen()

    def test_search_product(self, setup):

        self.logger.info("******* test_search_product *******")
        self.logger.info("******* Search Product on Amazon *******")
        self.driver = setup
        self.driver.maximize_window()
        self.driver.get(self.baseURL)

        self.logger.info("******* Search Product on Amazon *******")
        self.search = SearchProduct(self.driver)
        self.logger.info("******* Search Samsung Product on Amazon *******")
        self.search.searchbox("samsung")
        self.search.searchbutton()
        self.logger.info("******* Search Samsung Product on Amazon between 0 to 20000 *******")
        self.search.minprice("0")
        self.search.maxprice("20000")
        self.search.gofilter()

        self.logger.info("******* Select the Third Product in list *******")
        self.search.seleproduct()
        time.sleep(5)
        self.search.windowhandle()
        time.sleep(5)
        self.logger.info("******* Add the Selected product to Cart *******")
        self.search.addtocart()
        time.sleep(5)
        self.search.cartAdd()
        self.driver.quit()







